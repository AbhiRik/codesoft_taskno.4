import random

# Define possible choices
choices = ["rock", "paper", "scissors"]

def get_computer_choice():
    return random.choice(choices)

def get_winner(player_choice, computer_choice):
    if player_choice == computer_choice:
        return "tie"
    elif (player_choice == "rock" and computer_choice == "scissors") or \
         (player_choice == "paper" and computer_choice == "rock") or \
         (player_choice == "scissors" and computer_choice == "paper"):
        return "player"
    else:
        return "computer"

def play_round():
    player_choice = input("Enter your choice (rock, paper, or scissors): ").lower()
    while player_choice not in choices:
        print("Invalid choice. Please try again.")
        player_choice = input("Enter your choice (rock, paper, or scissors): ").lower()

    computer_choice = get_computer_choice()
    print(f"Computer chose: {computer_choice}")

    winner = get_winner(player_choice, computer_choice)
    return winner

def main():
    player_score = 0
    computer_score = 0

    for round_number in range(1, 6):
        print(f"\nRound {round_number}")
        winner = play_round()

        if winner == "player":
            player_score += 1
            print("You win this round!")
        elif winner == "computer":
            computer_score += 1
            print("Computer wins this round!")
        else:
            print("This round is a tie!")

        print(f"Current Score -> You: {player_score} Computer: {computer_score}")

    print("\nFinal Score:")
    print(f"You: {player_score}")
    print(f"Computer: {computer_score}")

    if player_score > computer_score:
        print("Congratulations! You won the game!")
    elif computer_score > player_score:
        print("Sorry, you lost the game. Better luck next time!")
    else:
        print("The game is a tie!")

if __name__ == "__main__":
    main()
